# Dataset directory

Place permitted local CSV files here. Do not commit sensitive, licensed, or restricted datasets.

Candidate dataset sources should be checked for provenance, version, license, schema, and actual row count before use. The supplied manuscript's exact named source files were not verified from the provided code. See `docs/DATASET_SOURCES.md`.

The current program's CSV adapter is generic and should be reviewed before research use; merely passing two files does not establish that their records or features can validly be combined.
