# DRRL-RF algorithm outline

1. Split records into train/validation/test (80:10:10).
2. Fit imputation and scaling on training records only.
3. Learn Gaussian RBF centers from training records and compute radial activations:
   `phi_j(x) = exp(-||x-c_j||^2 / (2*sigma^2))`.
4. Fit PCA to training radial activations, retaining 95% variance.
5. Initialize online Q-network, target network, replay buffer, epsilon-greedy policy, and residual state.
6. Select an action from the current state.
7. Compute simulated satisfaction, preference alignment, energy proxy, and latency proxy for that state/action.
8. Compute reward:
   `R = 0.35*satisfaction + 0.30*preference_alignment + 0.20*(1-energy_proxy) - 0.15*latency_proxy`.
9. Store transition and sample minibatches from replay memory.
10. Calculate TD target with the target network and TD error.
11. Update the residual TD-error state and apply its correction to the selected action target.
12. Train the online network and synchronize the target network periodically.
13. Evaluate the greedy policy on held-out states and repeat across seeds.

The bundled environment is illustrative. It is not a calibrated digital twin or a real hardware energy model.
