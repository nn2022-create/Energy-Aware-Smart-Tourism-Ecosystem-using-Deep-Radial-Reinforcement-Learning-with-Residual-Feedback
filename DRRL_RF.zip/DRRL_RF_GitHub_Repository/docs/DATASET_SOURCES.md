# Candidate dataset sources

These are candidate resources, not confirmed as the exact data files used in the manuscript.

- Tourism resource dataset candidate: https://github.com/kianadehmand/Tourism-dataset
- Trust Trackers for Computation Offloading in Edge-Based IoT Networks (Zenodo): https://doi.org/10.5281/zenodo.4339398
- Threat Modelling Guided Trust-Based Task Offloading in Resource-Constrained IoT Systems (Zenodo): https://doi.org/10.5281/zenodo.4568700
- Smart Tourism Technologies in Indonesia (Zenodo): https://zenodo.org/records/12771620

Before using a source, inspect its metadata, data dictionary, units, license, version, and actual record count. Do not concatenate unrelated datasets row-wise unless there is a defensible schema and experimental reason.
