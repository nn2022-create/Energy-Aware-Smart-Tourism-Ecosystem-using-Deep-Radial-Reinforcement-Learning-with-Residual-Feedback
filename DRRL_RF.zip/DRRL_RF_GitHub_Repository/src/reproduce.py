import os, json, random, argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import joblib
import tensorflow as tf
from tensorflow.keras import layers, models

ACTIONS = ["local", "edge_1", "edge_2", "cloud_1", "cloud_2"]

def set_seed(seed):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed); np.random.seed(seed)
    tf.keras.utils.set_random_seed(seed)

def synthetic_demo_data(n=6000, seed=2026):
    """Synthetic data for testing the pipeline only; not the manuscript's real dataset."""
    r = np.random.default_rng(seed)
    temp = r.normal(27, 5, n).clip(10, 42)
    humidity = r.normal(65, 12, n).clip(20, 95)
    noise = r.normal(70, 14, n).clip(35, 110)
    crowd = r.gamma(2.2, .8, n).clip(.1, 4)
    visitors = r.poisson(120 + 45*crowd)
    energy_use = (.25 + .12*crowd + r.normal(0, .08, n)).clip(0, 1)
    sat = np.clip(np.rint(4.5 - .24*crowd - .009*noise - .012*np.abs(temp-25) + r.normal(0,.45,n)),1,5)
    return pd.DataFrame({
        "temperature":temp, "humidity":humidity, "noise_level":noise,
        "crowd_density":crowd, "visitor_count":visitors, "resource_usage_rate":energy_use,
        "satisfaction_score":sat, "computation_load":r.lognormal(np.log(5.3e7),.35,n).clip(1e5,1e8),
        "bandwidth_mbps":r.uniform(1,100,n), "network_load":r.uniform(.05,1,n),
        "user_preference":r.uniform(0,1,n)
    })

def load_data(tourism=None, offloading=None, n_demo=6000, seed=2026):
    if not tourism and not offloading:
        return synthetic_demo_data(n_demo, seed), "synthetic_demo"
    frames = []
    for p in [tourism, offloading]:
        if p:
            d = pd.read_csv(p)
            d = d.select_dtypes(include=[np.number])
            if d.empty:
                raise ValueError(f"{p} has no numeric columns; encode categorical variables first.")
            frames.append(d)
    # Align columns without pretending that rows from separate datasets are linked.
    cols = sorted(set().union(*(set(x.columns) for x in frames)))
    return pd.concat([x.reindex(columns=cols) for x in frames], ignore_index=True), "user_csvs"

def preprocess_split(df, seed):
    df = df.replace([np.inf,-np.inf],np.nan).drop_duplicates().reset_index(drop=True)
    target_col = next((c for c in df.columns if c.lower() in
                       ["satisfaction_score","visitor_satisfaction","satisfaction","label","target","class"]), None)
    y = None
    if target_col:
        s = pd.to_numeric(df[target_col], errors="coerce")
        if s.notna().sum() and s.nunique(dropna=True) > 1:
            y = (s >= s.median()).astype(int).to_numpy()
    Xdf = df.select_dtypes(include=[np.number]).drop(columns=[target_col] if target_col else [])
    Xdf = Xdf.loc[:, Xdf.nunique(dropna=True) > 1]
    idx = np.arange(len(Xdf))
    train_idx, test_idx = train_test_split(idx, test_size=.10, random_state=seed)
    train_idx, val_idx = train_test_split(train_idx, test_size=1/9, random_state=seed)
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    Xtr = scaler.fit_transform(imputer.fit_transform(Xdf.iloc[train_idx]))
    Xval = scaler.transform(imputer.transform(Xdf.iloc[val_idx]))
    Xte = scaler.transform(imputer.transform(Xdf.iloc[test_idx]))
    rng = np.random.default_rng(seed)
    centers = Xtr[rng.choice(len(Xtr), min(50,len(Xtr)), replace=False)]
    sigma = 1.0
    def rbf(X):
        d2 = ((X[:,None,:] - centers[None,:,:])**2).sum(axis=2)
        return np.exp(-d2/(2*sigma*sigma))
    Rtr, Rval, Rte = rbf(Xtr), rbf(Xval), rbf(Xte)
    pca = PCA(n_components=.95, svd_solver="full")
    Ztr = pca.fit_transform(Rtr)
    Zval, Zte = pca.transform(Rval), pca.transform(Rte)
    prep = {"imputer":imputer,"scaler":scaler,"centers":centers,"sigma":sigma,
            "pca":pca,"columns":list(Xdf.columns),"target_column":target_col}
    return Ztr, Zval, Zte, prep

class Environment:
    """Illustrative normalized simulator, not a calibrated hardware energy model."""
    def __init__(self, X, seed=0):
        self.X = np.asarray(X, dtype=np.float32)
        self.rng = np.random.default_rng(seed)
    def reset(self):
        return self.X[int(self.rng.integers(len(self.X)))]
    def step(self, action, state):
        s = np.asarray(state)
        context = float(1/(1+np.exp(-np.mean(s))))
        spread = float(1/(1+np.exp(-np.std(s))))
        ebase = [.72,.50,.55,.66,.62][action]
        lbase = [.62,.42,.46,.54,.50][action]
        energy = float(np.clip(ebase+.12*context+.04*spread,0,1))
        latency = float(np.clip(lbase+.10*spread+.04*(1-context),0,1))
        satisfaction = float(np.clip(.58+.24*context+.10*(action in [1,3])-.08*latency,0,1))
        pref = float(np.clip(.55+.25*context+.12*(action in [2,4])-.08*energy,0,1))
        reward = .35*satisfaction+.30*pref+.20*(1-energy)-.15*latency
        ns = self.X[int(self.rng.integers(len(self.X)))]
        return ns, reward, False, {"satisfaction":satisfaction,"preference_alignment":pref,
                                   "energy_proxy":energy,"latency_proxy":latency}

def make_model(n_features, lr=1e-3):
    inp = layers.Input(shape=(n_features,))
    x = layers.Dense(128, activation="relu")(inp)
    h = layers.Dense(128, activation="relu")(x)
    res = layers.Dense(128)(h)
    x = layers.Add()([h,res])
    out = layers.Dense(len(ACTIONS), activation="linear")(x)
    m = models.Model(inp,out)
    m.compile(optimizer=tf.keras.optimizers.Adam(lr),loss="mse")
    return m

class DQNAgent:
    def __init__(self, n_features, seed):
        self.q = make_model(n_features)
        self.target = make_model(n_features)
        self.target.set_weights(self.q.get_weights())
        self.gamma=.92; self.epsilon=1.; self.eps_min=.02; self.eps_decay=.995
        self.memory=[]; self.capacity=10000; self.rng=random.Random(seed)
        self.residual=0.; self.rho=.20
    def act(self,s,greedy=False):
        if not greedy and self.rng.random()<self.epsilon:
            return self.rng.randrange(len(ACTIONS))
        return int(np.argmax(self.q.predict(np.asarray(s)[None,:],verbose=0)[0]))
    def remember(self,t):
        self.memory.append(t)
        if len(self.memory)>self.capacity: self.memory.pop(0)
    def train_step(self,batch=32):
        if len(self.memory)<batch: return np.nan
        b=self.rng.sample(self.memory,batch)
        S=np.stack([x[0] for x in b]); A=np.array([x[1] for x in b])
        R=np.array([x[2] for x in b]); NS=np.stack([x[3] for x in b]); D=np.array([x[4] for x in b])
        qvals=self.q.predict(S,verbose=0); nq=self.target.predict(NS,verbose=0)
        targets=qvals.copy(); errors=[]
        for i in range(batch):
            y=R[i]+self.gamma*(1-D[i])*np.max(nq[i])
            delta=y-qvals[i,A[i]]
            self.residual=self.rho*self.residual+(1-self.rho)*float(delta)
            targets[i,A[i]]=y+.10*self.residual
            errors.append(delta)
        self.q.train_on_batch(S,targets)
        self.epsilon=max(self.eps_min,self.epsilon*self.eps_decay)
        return float(np.mean(np.square(errors)))

def train_run(Xtr, seed, episodes, steps):
    set_seed(seed); agent=DQNAgent(Xtr.shape[1],seed); env=Environment(Xtr,seed)
    rows=[]; total_steps=0
    for ep in range(episodes):
        s=env.reset(); rewards=[]; losses=[]
        for _ in range(steps):
            a=agent.act(s)
            ns,r,done,info=env.step(a,s)
            agent.remember((s,a,r,ns,done)); loss=agent.train_step()
            if np.isfinite(loss): losses.append(loss)
            rewards.append(r); s=ns; total_steps+=1
            if total_steps%100==0: agent.target.set_weights(agent.q.get_weights())
        rows.append({"seed":seed,"episode":ep+1,"mean_reward":np.mean(rewards),
                     "td_loss":np.mean(losses) if losses else np.nan,"epsilon":agent.epsilon})
    return agent,pd.DataFrame(rows)

def evaluate(agent, Xte, max_samples=2000):
    env=Environment(Xte,seed=9001); rows=[]
    for s in Xte[:max_samples]:
        a=agent.act(s,greedy=True); _,r,_,info=env.step(a,s)
        rows.append({"action":ACTIONS[a],"reward":r,**info})
    d=pd.DataFrame(rows)
    return {"mean_reward":float(d.reward.mean()),"satisfaction_mean":float(d.satisfaction.mean()),
            "preference_alignment_mean":float(d.preference_alignment.mean()),
            "energy_proxy_mean":float(d.energy_proxy.mean()),"latency_proxy_mean":float(d.latency_proxy.mean())},d

def plots(log, metrics, baselines):
    p=Path("outputs/figures"); p.mkdir(parents=True,exist_ok=True)
    plt.figure(figsize=(8,5))
    for seed,g in log.groupby("seed"): plt.plot(g.episode,g.mean_reward,label=f"seed {seed}")
    if log.seed.nunique()>1: plt.legend()
    plt.xlabel("Episode"); plt.ylabel("Mean simulated reward"); plt.title("Figure 1. Training convergence")
    plt.tight_layout(); plt.savefig(p/"fig1_learning_curve.png",dpi=300); plt.close()
    keys=["mean_reward","satisfaction_mean","preference_alignment_mean"]
    plt.figure(figsize=(8,5)); plt.bar(["Reward","Satisfaction","Preference alignment"],[metrics[k].mean() for k in keys])
    plt.ylabel("Normalized mean"); plt.title("Figure 2. Held-out policy metrics")
    plt.tight_layout(); plt.savefig(p/"fig2_test_metrics.png",dpi=300); plt.close()
    plt.figure(figsize=(7,5)); plt.bar(["Energy proxy","Latency proxy"],[metrics.energy_proxy_mean.mean(),metrics.latency_proxy_mean.mean()])
    plt.ylabel("Normalized simulated cost"); plt.title("Figure 3. Energy and latency proxies")
    plt.tight_layout(); plt.savefig(p/"fig3_energy_latency.png",dpi=300); plt.close()
    plt.figure(figsize=(8,5)); plt.bar(baselines.variant,baselines.mean_reward)
    plt.ylabel("Mean simulated reward"); plt.xticks(rotation=20,ha="right"); plt.title("Figure 4. Fixed-action baseline comparison")
    plt.tight_layout(); plt.savefig(p/"fig4_baselines.png",dpi=300); plt.close()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--tourism"); ap.add_argument("--offloading")
    ap.add_argument("--runs",type=int,default=3); ap.add_argument("--episodes",type=int,default=30)
    ap.add_argument("--steps",type=int,default=80); ap.add_argument("--n-demo",type=int,default=6000)
    ap.add_argument("--seed",type=int,default=2026); args=ap.parse_args()
    Path("outputs").mkdir(exist_ok=True)
    df,mode=load_data(args.tourism,args.offloading,args.n_demo,args.seed)
    Xtr,Xval,Xte,prep=preprocess_split(df,args.seed)
    logs=[]; metrics=[]; preds=[]
    for i in range(args.runs):
        seed=args.seed+i
        agent,log=train_run(Xtr,seed,args.episodes,args.steps); logs.append(log)
        m,pred=evaluate(agent,Xte); m.update({"seed":seed,"data_mode":mode}); metrics.append(m)
        pred["seed"]=seed; preds.append(pred)
        agent.q.save(f"outputs/model_seed_{seed}.keras")
        joblib.dump(prep,f"outputs/preprocessing_seed_{seed}.joblib")
    log=pd.concat(logs,ignore_index=True); met=pd.DataFrame(metrics)
    log.to_csv("outputs/training_log.csv",index=False); met.to_csv("outputs/run_metrics.csv",index=False)
    pd.concat(preds,ignore_index=True).to_csv("outputs/test_policy_outputs.csv",index=False)
    numeric=met.select_dtypes(include=[np.number]).drop(columns=["seed"],errors="ignore")
    pd.DataFrame({"metric":numeric.columns,"mean":numeric.mean().values,
                  "std":numeric.std(ddof=1).fillna(0).values}).to_csv("outputs/metrics_summary.csv",index=False)
    # Simple baselines use the same test states and the same illustrative environment.
    base=[]
    for name,a in zip(["Always local","Always edge_1","Always edge_2","Always cloud_1","Always cloud_2"],range(5)):
        env=Environment(Xte,seed=9001); rr=[]
        for s in Xte[:min(2000,len(Xte))]:
            _,r,_,_=env.step(a,s); rr.append(r)
        base.append({"variant":name,"mean_reward":float(np.mean(rr))})
    baselines=pd.DataFrame(base); baselines.to_csv("outputs/baseline_comparison.csv",index=False)
    plots(log,met,baselines)
    config=vars(args); config.update({"data_mode":mode,"rows":len(df),"train_rows":len(Xtr),
        "validation_rows":len(Xval),"test_rows":len(Xte),"actions":ACTIONS,
        "caveat":"Synthetic/demo or simulator outputs are not measured real-world results."})
    with open("outputs/config.json","w") as f: json.dump(config,f,indent=2)
    print("Finished. Data mode:",mode)
    print(pd.read_csv("outputs/metrics_summary.csv").to_string(index=False))
    print("See outputs/ for metrics, models, logs and four figures.")
    print("Do not report simulator proxies as measured watts/seconds or use demo metrics as manuscript results.")

if __name__=="__main__": main()
